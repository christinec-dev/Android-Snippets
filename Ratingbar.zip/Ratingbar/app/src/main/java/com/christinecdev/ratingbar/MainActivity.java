package com.christinecdev.ratingbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RatingBar rt1, rt2;
    Button save;
    TextView average;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rt1 = findViewById(R.id.ratingBarOne);
        rt2 = findViewById(R.id.ratingBarTwo);
        save = findViewById(R.id.button);
        average = findViewById(R.id.textViewAverage);

        //save ratings and calculate average
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //getsd values of rt1 and rt2 chosen by user
                String ratingOne = String.valueOf(rt1.getRating());
                String ratingTwo = String.valueOf(rt2.getRating());

                //calculates the average
                float avg = 0;
                avg += Float.parseFloat(ratingOne);
                avg += Float.parseFloat(ratingTwo);
                float avgTotal = avg / 2;

                //sets average
                average.setText(String.valueOf(avgTotal) + "/6");
            }
        });
    }
}