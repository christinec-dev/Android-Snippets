package com.christinecdev.customadapter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList <Item> androidVersionList = new ArrayList <>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Getting the reference of listView
        listView = (ListView) findViewById(R.id.listView);

        // Adding image and texts to list
        androidVersionList.add(new Item(R.drawable.banana, "Donut", "1.6"));
        androidVersionList.add(new Item(R.drawable.banana, "Eclair", "2.0 - 2.1"));
        androidVersionList.add(new Item(R.drawable.banana, "Froyo", "2.2 - 2.2.3"));
        androidVersionList.add(new Item(R.drawable.banana, "GingerBreak", "2.3 - 2.3.7"));
        androidVersionList.add(new Item(R.drawable.banana, "HoneyComb", "3.0 - 3.2.6"));
        androidVersionList.add(new Item(R.drawable.banana, "IceCream", "4.0 - 4.0.4"));
        androidVersionList.add(new Item(R.drawable.banana, "JellyBean", "4.1 - 4.3.1"));
        androidVersionList.add(new Item(R.drawable.banana, "KitKat", "4.4 - 4.4.4"));
        androidVersionList.add(new Item(R.drawable.banana, "Lollipop", "5.0 - 5.1.1"));
        androidVersionList.add(new Item(R.drawable.banana, "Marshmallow", "6.0 - 6.0.1"));

        Adapter adapter = new Adapter(this, R.layout.list_item, androidVersionList);

        // Setting the adapter to list
        listView.setAdapter(adapter);
    }
}