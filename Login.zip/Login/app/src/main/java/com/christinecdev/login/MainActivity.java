package com.christinecdev.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public EditText username, password;
    public Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        login = findViewById(R.id.buttonLogin);

        //button to perform user validation
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //basic username and password validation with hardcoded values
                if(username.getText().toString().equals("christine") && password.getText().toString().equals("qwerty123")){
                    Intent i = new Intent(MainActivity.this, SuccessfulLogin.class);
                    startActivity(i);
                    finish(); //takes to success login activity
                } else {
                    Toast.makeText(getApplicationContext(),"Please enter valid credentials.", Toast.LENGTH_LONG).show();
                    username.requestFocus();
                    password.requestFocus(); //refocuses on fields for credentials
                }
            }
        });
    }
}