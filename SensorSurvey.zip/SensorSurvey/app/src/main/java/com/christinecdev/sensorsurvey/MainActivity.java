package com.christinecdev.sensorsurvey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorAdditionalInfo;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    Sensor mSensorProximity;
    Sensor mSensorLight;
    SensorManager mSensorManager;
    TextView proximity, light;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        proximity = findViewById(R.id.label_proximity);
        light = findViewById(R.id.label_light);

        //gets instances of sensors
        mSensorProximity = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        mSensorLight = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        //err message if sensor not available
        String sensor_error = getResources().getString(R.string.error_no_sensor);

        //checks if sensor is available to give err msg/start sensor
        if (mSensorLight == null)
        {
            light.setText(sensor_error);
        }

        if (mSensorProximity == null)
        {
            proximity.setText(sensor_error);
        }

        //each sensor needs its own register to listen
        if (mSensorProximity != null) {
            mSensorManager.registerListener(this, mSensorProximity, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (mSensorLight != null) {
            mSensorManager.registerListener(this, mSensorLight, SensorManager.SENSOR_DELAY_NORMAL);
        }

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        // The sensor type (as defined in the Sensor class).
        int sensorType = sensorEvent.sensor.getType();

        // The new data value of the sensor.  Both the light and proximity
        // sensors report one value at a time, which is always the first
        // element in the values array.
        float currentValue = sensorEvent.values[0];

        switch (sensorType) {
            // Event came from the light sensor.
            case Sensor.TYPE_LIGHT:
                light.setText(getResources().getString(R.string.label_light, currentValue));
                break;

            case Sensor.TYPE_PROXIMITY:
                proximity.setText(getResources().getString(R.string.label_proximity, currentValue));
                break;

            default:
                // do nothing
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        //nothing
    }

    //method to unregister your sensor listeners when the app pauses
    @Override
    protected void onStop() {
        super.onStop();
        mSensorManager.unregisterListener(this);
    }
}