package com.christinecdev.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivityy extends AppCompatActivity {

    TextView responseMessage, responseName;
    Button sendBack;
    String message, name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_activityy);

        responseName = findViewById(R.id.textViewName);
        responseMessage = findViewById(R.id.textViewMessage);
        sendBack = findViewById(R.id.buttonBack);

        //get intent
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        //sets the data from the edittexts on main activity to textviews
        if(bundle != null){
            message = bundle.getString("message");
            name = bundle.getString("name");
            responseMessage.setText(message);
            responseName.setText(name);
        }

        //returns to min activity
        sendBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SecondActivityy.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}