package com.christinecdev.intents;

public class EXTRA_MESSAGE {
}
