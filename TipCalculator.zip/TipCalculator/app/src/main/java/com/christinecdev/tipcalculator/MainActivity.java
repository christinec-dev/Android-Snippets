package com.christinecdev.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText billAmount;
    Button fifteen, eighteen, twenty;
    TextView tipAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            billAmount = findViewById(R.id.editTextTextBillAmount);
            fifteen = findViewById(R.id.buttonFifteen);
            eighteen = findViewById(R.id.buttonEighteen);
            twenty = findViewById(R.id.buttonTwenty);
            tipAmount = findViewById(R.id.textViewResult);

            fifteen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int tip = Integer.parseInt(String.valueOf(billAmount.getText()));
                    tipAmount.setText("Tip: R" + tip * 15/100 + "; Total Bill: R" + billAmount.getText());
                }
            });

        eighteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int tip = Integer.parseInt(String.valueOf(billAmount.getText()));
                tipAmount.setText("Tip: R" + tip * 18/100 + "; Total Bill: R" + billAmount.getText());
            }
        });

        twenty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int tip = Integer.parseInt(String.valueOf(billAmount.getText()));
                tipAmount.setText("Tip: R" + tip * 20/100 + "; Total Bill: R" + billAmount.getText());
            }
        });
    }
}