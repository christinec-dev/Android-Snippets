package com.christinecdev.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name, age;
    Button save, view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editTextName);
        age = findViewById(R.id.editTextAge);
        save = findViewById(R.id.buttonSave);
        view = findViewById(R.id.buttonView);

        // Store the data in the SharedPreference
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit(); //edit() method

                // write all the data entered by the user in SharedPreference and apply
                myEdit.putString("name", name.getText().toString());
                myEdit.putInt("age", Integer.parseInt(age.getText().toString()));
                myEdit.commit();//commit() method
            }
        });

        // Get the data in the SharedPreference
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // fetching the stored data from the SharedPreference
                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);

                String nameValue = sharedPreferences.getString("name", "");
                int ageValue = sharedPreferences.getInt("age", 0);

                // showing the SharedPreference values in toast message
                Toast.makeText(getApplicationContext(),
                        "Name: " + nameValue + " ;Age: " + ageValue,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // fetch the stored data in onResume() Because this is what will be called when the app opens again
    @Override
    protected void onResume() {
        super.onResume();
        // fetching the stored data from the SharedPreference
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        String nameValue = sharedPreferences.getString("name", "");
        int ageValue = sharedPreferences.getInt("age", 0);

        // Setting the fetched data in the EditTexts
        name.setText(nameValue);
        age.setText(String.valueOf(ageValue));
    }
}